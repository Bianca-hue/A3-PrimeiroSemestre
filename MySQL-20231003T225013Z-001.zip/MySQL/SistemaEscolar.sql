DROP DATABASE IF EXISTS SistemaEscolar;
CREATE DATABASE SistemaEscolar;
USE SistemaEscolar;


CREATE TABLE Rua(
    IdRua INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(80) NOT NULL
);
CREATE TABLE Bairro(
    IdBairro INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(80) NOT NULL
);
CREATE TABLE Curso(
	IdCurso INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(80) NOT NULL,
    CargaHoraria INT NOT NULL,
    Descricao TEXT
);
CREATE TABLE Pessoa (
    IdPessoa INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(80) NOT NULL,
    CPF VARCHAR(11) UNIQUE KEY NOT NULL,
    Celular VARCHAR(11) NOT NULL,
    Rua INT NOT NULL,
    Bairro INT NOT NULL,
    Numero INT NOT NULL,
    Complemento VARCHAR(80),
    FOREIGN KEY (Rua) REFERENCES Rua(IdRua),
    FOREIGN KEY (Bairro) REFERENCES Bairro(IdBairro)
);
CREATE TABLE Aluno(
	Matricula INT PRIMARY KEY AUTO_INCREMENT,
    IdPessoa INT UNIQUE KEY NOT NULL,
    Curso INT NOT NULL,
    DataCriacao DATE DEFAULT CURRENT_TIMESTAMP,
    DataCancelamento DATE DEFAULT NULL,
    FOREIGN KEY (IdPessoa) REFERENCES Pessoa(IdPessoa),
    FOREIGN KEY (Curso) REFERENCES Curso(IdCurso)
);
CREATE TABLE Professor(
	CodFuncionario INT PRIMARY KEY AUTO_INCREMENT,
    IdPessoa INT UNIQUE KEY NOT NULL,
    FOREIGN KEY (IdPessoa) REFERENCES Pessoa(IdPessoa)
);
CREATE TABLE Sala(
    NumeroSala INT PRIMARY KEY NOT NULL,
    Andar VARCHAR(10) NOT NULL,
    Capacidade INT NOT NULL
);
CREATE TABLE Turma(
    IdTurma INT PRIMARY KEY AUTO_INCREMENT,
    NumeroSala INT NOT NULL,
    DiaSemana VARCHAR(20) NOT NULL,
    CodFuncionario INT NOT NULL,
    Curso INT NOT NULL,
    FOREIGN KEY (CodFuncionario) REFERENCES Professor(CodFuncionario),
    FOREIGN KEY (NumeroSala) REFERENCES Sala(NumeroSala),
    FOREIGN KEY (Curso) REFERENCES Curso(IdCurso)
);
-- Associativa entre aluno e turma
CREATE TABLE ListaAlunos(
    IdListaAlunos INT PRIMARY KEY AUTO_INCREMENT,
    Matricula INT NOT NULL,
    IdTurma INT NOT NULL,
    FOREIGN KEY (Matricula) REFERENCES Aluno(Matricula),
    FOREIGN KEY (IdTurma) REFERENCES Turma(IdTurma)
);

-- INSERÇÃO BASICA DE DADOS
INSERT INTO Rua(Nome) VALUES 
("Getulio Vargas"),
("São Paulo");
INSERT INTO Bairro(Nome) VALUES
("Anita Garibaldi"),
("Itaum");
INSERT INTO Curso(Nome, CargaHoraria, Descricao) VALUES
("Técnologo Gestão de TI",120,"Técnologo pra gente doida <3"),
("Bacharelado Analise e Desenvolvimento de Sistemas",240,"Bacharelado pra doidinho tbm");
INSERT INTO Pessoa(Nome,CPF,Celular,Rua,Bairro,Numero,Complemento) VALUES 
("Pedro","12345678910","47912345678",1,1,123,"APTO 101"),
("Vivian","12345678911","47912341234",1,1,123,"APTO 102"),
("Lucas","12345678912","47912344321",2,2,45,"");
INSERT INTO Aluno(IdPessoa,Curso) VALUES
("1","1"),
("2","2");
INSERT INTO Professor(IdPessoa) VALUES
("3");
INSERT INTO Sala(NumeroSala, Andar, Capacidade) VALUES
(101, "1º Andar", 20),
(102, "1º Andar", 2),
(201, "2º Andar", 40);
INSERT INTO Turma(NumeroSala, DiaSemana, CodFuncionario, Curso) VALUES
(101, "Terça",1,1),
(102, "Quinta",1,2);
INSERT INTO ListaAlunos(Matricula, IdTurma) VALUES
(1,1),
(2,1);